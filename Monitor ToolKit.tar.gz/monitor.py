import sys, os, subprocess
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *

global password
password = open("pwd", "r+")
password.seek(0)
password = password.read().split("\n")[0]

class App(QMainWindow):
  def __init__(self):
    super().__init__()
    rect = app.primaryScreen().availableGeometry()
    self.title = "Monitor ToolKit"
    self.width = 510
    self.height = 240
    self.left = (rect.width() / 2) - (self.width / 2)
    self.top = (rect.height() / 2) - (self.height / 2)
    self.initUI()

    if password == "" or len(password) == 0:
      dlg = QMessageBox(self)
      dlg.setWindowTitle("No password provided!")
      dlg.setText(f"No password provided in 'pwd' file")
      dlg.exec()

      sys.exit()
      
  def initUI(self):
    self.setWindowTitle(self.title)
    self.move(self.left, self.top)
    self.setFixedSize(self.width, self.height)
    self.setWindowIcon(QIcon("icon.png"))
    self.setStyleSheet("background: rgb(27, 27, 27); color: white")

    self.appTitle = QLabel(self.title, self)
    self.appTitle.setGeometry(10, 10, 1000, 100)
    self.appTitle.setStyleSheet("font-size: 30px")

    self.monitorLabel = QLabel("Monitor", self)
    self.monitorLabel.setGeometry(400, 30, 100, 30)

    self.monitor = QLineEdit("", self)
    self.monitor.setGeometry(400, 60, 100, 30)


    # +------------+
    # | RESOLUTION |
    # +------------+

    self.resLabel = QLabel("Resolution", self)
    self.resLabel.setGeometry(20, 170, 100, 30)

    self.resWINP = QLineEdit(self)
    self.resWINP.setGeometry(10, 200, 100, 30)

    self.resHINP = QLineEdit(self)
    self.resHINP.setGeometry(140, 200, 100, 30)

    self.resXLABEL = QLabel("x", self)
    self.resXLABEL.setGeometry(120, 200, 10, 30)


    # +-------------+
    # | REFRESHRATE |
    # +-------------+

    self.refLabel = QLabel("Refresh Rate", self)
    self.refLabel.setGeometry(290, 170, 100, 30)

    self.refRate = QLineEdit(self)
    self.refRate.setGeometry(280, 200, 100, 30)

    self.resHZLABEL = QLabel("hz", self)
    self.resHZLABEL.setGeometry(390, 200, 30, 30)



    self.applyButton = QPushButton("Apply", self)
    self.applyButton.setGeometry(400, 100, 100, 30)
    self.applyButton.clicked.connect(self.setResolution)

    self.show()
  
  def setResolution(self):
    resW = int(self.resWINP.text())
    resH = int(self.resHINP.text())
    ref = int(self.refRate.text())

    monitor = self.monitor.text()

    if monitor == "" or len(monitor) == 0:
      self.monitor.setFocus(True)
      return

    cvt = subprocess.Popen(["cvt", str(resW), str(resH), str(ref)], stdout=subprocess.PIPE).communicate()[0]
    
    cvt = str(cvt).split("Modeline")[1].replace("\\n", "").replace("'", "")

    cvtMode = cvt.split(" ")[1]

    osCmd = f"echo {password}|sudo -S xrandr --newmode {cvt} && echo {password}|sudo -S xrandr --addmode {monitor} {cvtMode}"
    applyCmd = f"echo {password}|sudo -S xrandr --output {monitor} --mode {cvtMode}"

    print(osCmd)

    os.system(osCmd)

    sod_buttons = QDialogButtonBox.Yes | QDialogButtonBox.No
    setOutputDialog = QMessageBox(self)
    setOutputDialog.setWindowTitle("Apply settings")
    setOutputDialog.setText("Do you want to apply changes?")
    applyChanges = setOutputDialog.exec()

    if applyChanges == QMessageBox.Ok:
      os.system(applyCmd)

if __name__ == "__main__":
    app = QApplication.instance()
    if app is None:
        app = QApplication(sys.argv)

    ex = App()
    app.exec_() 
