#!/bin/bash

CALC="ucicalc"
CALCDIR="/bin/"

sudo rm $CALCDIR$CALC

echo "Checking files..."

if [[ $(ls $CALCDIR) == *"$CALC"* ]]; then
    echo "$CALCDIR$CALC – Failed"
else
    echo "$CALCDIR$CALC – Success"
fi