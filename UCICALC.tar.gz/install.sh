#!/bin/bash

CALC="ucicalc"
CALCDIR="/bin/"

echo "Copying files..."

sudo cp $CALC $CALCDIR

echo "Checking files..."

LSCMD=$(ls $CALCDIR)

if [[ $(ls $CALCDIR) == *"$CALC"* ]]; then
    echo "$CALCDIR$CALC – Success"
else
    echo "$CALCDIR$CALC – Failed"
fi

echo
echo "Do you want to install Python and required module(s)? (If you don't have them installed)
To download:
- Python3
- termcolor 1.1.0 (PIP)"
echo "Press ENTER to continue..."

read

sudo apt install python3
sudo apt-get install python3
sudo pacman -S python3

python3 -m pip install termcolor