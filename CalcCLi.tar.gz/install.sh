#!/bin/bash

sudo apt install python3
sudo apt-get install python3
sudo pacman -S python3

python3 -m pip install termcolor

sudo cp calccli /bin/
sudo cp calccli_help.txt /bin/

LSCMD=$(ls /bin/)

echo "Checking files..."

if [[ $LSCMD == *"calccli"* ]]; then
    echo "/bin/calccli – Success"
else
    echo "/bin/calccli – Failed"
fi

if [[ $LSCMD == *"calccli_help.txt"* ]]; then
    echo "/bin/calccli_help.txt – Success"
else
    echo "/bin/calccli_help.txt – Failed"
fi