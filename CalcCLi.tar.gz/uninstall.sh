#!/bin/bash

sudo rm /bin/calccli
sudo rm /bin/calccli_help.txt

LSCMD=$(ls /bin/)

echo "Checking files..."

if [[ $LSCMD == *"calccli"* ]]; then
    echo "/bin/calccli – Failed"
else
    echo "/bin/calccli – Success"
fi

if [[ $LSCMD == *"calccli_help.txt"* ]]; then
    echo "/bin/calccli_help.txt – Failed"
else
    echo "/bin/calccli_help.txt – Success"
fi