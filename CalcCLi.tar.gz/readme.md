# CalcCLI

### Table of Content
- [Installation](#how-to-install)
- [Usage](#usage)
- [Source Code](calccli)
- [Help](calccli_help.txt)

### How to Install
#### Requirements:
- OS: Linux

You can use [installer](install.sh) to Install CalcCLI<br>
OR install manually.
#### Dependencies:
- [Python](https://www.python.org/downloads/) 3.8.10
- [termcolor](https://pypi.org/project/termcolor/) 1.1.0
```sh
pip install termcolor
```
OR
```sh
python3 -m pip install termcolor
```

### Usage
In terminal:
```sh
calccli "YOUR OPERATION"
```
```sh
calccli "2 + 2"
# 2 + 2  =  4
```